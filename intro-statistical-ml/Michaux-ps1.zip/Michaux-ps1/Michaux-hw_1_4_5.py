
# coding: utf-8

# In[1]:

import pandas as pd
import h5py
import numpy as np
from pset1 import degexpand
import seaborn as sns
import matplotlib.pyplot as plt
get_ipython().magic('matplotlib inline')

def normal_equation(X,y):
    w = np.linalg.inv(np.transpose(X).dot(X)).dot(np.transpose(X)).dot(y)
    return w

def polynomial_coeff(X,y, deg):
    w_hat = normal_equation(X,y) 
    return w_hat 

def partition(input_data,fold):
    n,m = np.shape(input_data)
    indices = np.arange(n)
    #shuffle indices
    np.random.shuffle(indices)
    partition = np.array_split(indices,fold)
    return partition

def cross_validate(X,y, deg, kfold):
    part = partition(X,kfold)
    X = X[:,0:deg+1]
    errors = 0
    for i in range(kfold):
        X_test = X[part[i]]
        Y_test = y[part[i]]
        X_train = np.delete(X, part[i], axis=0)
        Y_train = np.delete(y, part[i], axis=0)
        w_train = normal_equation(X_train, Y_train)
        run_error = squared_loss(X_test, Y_test, w_train)
        #print(np.mean(run_error))
        errors += np.mean(run_error)
    return  errors/kfold
        
    
    

def squared_loss(X,y,w):
    return np.mean((y-X.dot(w))**2)



def cross_validate_silly(X,y, deg, kfold,wrange,silly_loss):
    part = partition(X,kfold)
    X = X[:,0:deg+1]
    errors = 0
    for i in range(kfold):
        X_test = X[part[i]]
        Y_test = y[part[i]]
        X_train = np.delete(X, part[i], axis=0)
        Y_train = np.delete(y, part[i], axis=0)
        w_train = test_ws(X_train, Y_train, wrange, silly_loss)
        run_error = silly_loss(np.dot(X_test,w_train[1]), Y_test)
        errors += np.mean(run_error)
    return  errors/kfold


#This is actually the  negative log-likelihood of the exponential noise model
def silly_loss(yhat,y):
    #mask = ma.masked_less((y-yhat), 0) #where is this less than zero
    err = y-yhat
    neg = err[err<0]
    pos = err[err>=0]
    c1 = np.size(pos) * np.log(0.95)
    c2 = np.size(neg) * np.log(0.05)
    assert np.size(pos) + np.size(neg) == np.size(err)
    #if neg.size > 0:
     #   import pdb; pdb.set_trace()
    return -(c2 + np.sum(neg) + c1 - np.sum(pos))
    
def log_likelihood(X,y,w):
    err = np.mean((y - np.dot(X,w)))
    var_biased = np.mean((err-mean_err)**2)
    var_unbiased = (np.size(err)*var_biased) / (np.size(err) - 1)
    N = np.size(err)
    return -(1/(2*(var_unbiased))) * np.mean(err**2) - (N/2) * np.log(2* var_unbiased * np.pi)
    
    
    
def test_ws(X, y, wrange, lossfunc):
    """
    Tests a range of parameters against a loss function.

    Parameters
    ----------
    X : 2D array
        N x d+1 design matrix (row per example)
    y : 1D array
        Observed function values
    wrange : list of arrays
        A list of arrays with parameters that should be tested. The value
        wrange[j] is a range over which the j-th coefficient has to run.
    lossfunc : function
        Function pointer to compute empirical loss. lossfunc is assumed to
        take two arguments: yhat (estimated) and y (observed).

    Returns
    -------
    losses : 2D array
        losses[i, j] is the value of the loss for the corresponding set of
        parameter (regression coefficient) values.
    """
    assert np.ndim(X) == 2, "X must be 2D"
    assert X.shape[1] == len(wrange), "Sizes of X and wrange should match"

    ws = np.reshape(np.meshgrid(*wrange, indexing='ij'), (len(wrange), -1))
    yhat = np.dot(X, ws)

    loss = np.zeros(yhat.shape[1])
    for i in range(len(loss)):
        loss[i] = lossfunc(yhat[:, i], y)
    w_hat = ws[:,np.argmin(loss)]
    return loss.reshape([len(w) for w in wrange]),w_hat
    

    
    


# In[2]:

#load training data
with h5py.File('fortgauss.h5', 'r') as g:
    training_data = g['data08'][()]

#load test data
with h5py.File('fortgauss.h5', 'r') as f:
    test_data_2009 = f['data09'][()]

#Make the design matrix for the linear and quadratic fit    
[linear_train_data, linear_scale] = degexpand(training_data,1,C=None)    
[quadratic_train_data, quadratic_scale] = degexpand(training_data,2,C=None)    

#Put output data for training and testing into arrays
y_train = training_data[:,1]
y_test = test_data_2009[:,1]

#Put input testing data, appropriately scaled, into arrays
[linear_test_data,linear_test_scale] = degexpand(test_data_2009,1,linear_scale)
[quadratic_test_data, quadratic_test_scale] = degexpand(test_data_2009,2,quadratic_scale)


# Problem 4

# In[4]:

#Determine the coefficients for best linear and quadratic fits using OLS

#Linear Fit 
linear_coeff = polynomial_coeff(linear_train_data[:,0:2],y_train, 1)
print("The coefficients for the linear fit are",linear_coeff)

#Quadratic Fit
quadratic_coeff = polynomial_coeff(quadratic_train_data[:,0:3],y_train, 2)
print("The coefficients for the quadratic fit are",quadratic_coeff)



# In[5]:

#Plots
t = np.arange(0.0, 1.0, 0.01)
line = np.array(linear_coeff[0] + linear_coeff[1] * t)
quad = np.array(quadratic_coeff[0] + quadratic_coeff[1] * t + quadratic_coeff[2] * (t**2))


with sns.axes_style("darkgrid"):
    fig, ax = plt.subplots()
    ax.set_title('Linear Fit under Gaussian Noise')
    ax.plot(linear_train_data[:,1],y_train,'o', label = 'data')
    ax.plot(t,line)
    ax.legend(['2008 Data', 'Linear Fit'], loc='best')
    ax.set(ylim=(0, 10))
    ax.set(xlim=(0, 1.05))
    plt.show()


with sns.axes_style("darkgrid"):
    fig, ax = plt.subplots()
    ax.set_title('Quadratic Fit under Gaussian Noise')
    ax.plot(quadratic_train_data[:,1],y_train,'o', label = 'data')
    ax.plot(t,quad)
    ax.legend(['2008 Data', 'Quadratic Fit'], loc='best')
    ax.set(ylim=(0, 10))
    ax.set(xlim=(0, 1.05))
    plt.show()

#Generate plot with model chosen by cross validation    
with sns.axes_style("darkgrid"):
    fig, ax = plt.subplots()
    ax.set_title('Quadratic model selected by Cross-Validation')
    ax.plot(quadratic_test_data[:,1],y_test,'o', label = 'data')
    ax.plot(t,quad)
    ax.legend(['2009 Data', 'Quadratic Fit'], loc='best')
    ax.set(ylim=(0, 10))
    ax.set(xlim=(0, 1.05))
    plt.show()


# In[6]:

#Model Selection by 10-fold cross validation
linear_cv_error = cross_validate(linear_train_data, y_train,1,10)
print("The average MSE under 10-fold cross-validation for the linear model is", linear_cv_error)

quadratic_cv_error = cross_validate(quadratic_train_data, y_train,2,10)
print("The average MSE under 10-fold cross-validation for the quadratic model is",quadratic_cv_error)


# In[7]:

#Empirical Loss on training data
quadratic_empirical_loss_train = squared_loss(quadratic_train_data[:,0:3],y_train, quadratic_coeff)
print("The empirical loss on the 2008 training data with the quadratic fit is",quadratic_empirical_loss_train)

#Log-likelihood on test data
#Calculate mu and sigma^2 from the training data
err = y_train - np.dot(quadratic_train_data[:,0:3],quadratic_coeff)
mu_ML = np.mean(err)
sigma_squared = np.mean((err-mu_ML)**2)

#Use the sigma^2 from the training data to determine the log-likelihood of the test data
train_err = y_train - np.dot(quadratic_train_data[:,0:3],quadratic_coeff)
N = np.size(y_train)
log_likelihood = -(1/(2*(sigma_squared))) * np.sum(train_err**2) - (N/2) * np.log(2* sigma_squared * np.pi)

print("The log-likelihood of the 2008 training data under gaussian noise is", log_likelihood)


# In[8]:

#Empirical Loss on Test data
quadratic_empirical_loss = squared_loss(quadratic_test_data[:,0:3],y_test, quadratic_coeff)
print("The empirical loss on the 2009 test data with the quadratic fit is",quadratic_empirical_loss)

#Log-likelihood on test data
#Calculate mu and sigma^2 from the training data
err = y_train - np.dot(quadratic_train_data[:,0:3],quadratic_coeff)
mu_ML = np.mean(err)
sigma_squared = np.mean((err-mu_ML)**2)

#Use the sigma^2 from the training data to determine the log-likelihood of the test data
test_err = y_test - np.dot(quadratic_test_data[:,0:3],quadratic_coeff)
N = np.size(y_test)
log_likelihood = -(1/(2*(sigma_squared))) * np.sum(test_err**2) - (N/2) * np.log(2* sigma_squared * np.pi)

print("The log-likelihood of the 2009 test data under gaussian noise is", log_likelihood)


# Problem 5

# In[9]:

#Use cross-validation to select the best model class
#Empirical loss and Log-likelihood

#Empirical loss and Log-likelihood
steps2 = np.arange(-10,10.5,0.5)
wrange2 = np.array([steps2,steps2])
print("The mean error for 10-fold cross validation of the linear model is", cross_validate_silly(linear_train_data[:,0:2],y_train,1,10,wrange2,silly_loss))


steps3 = np.arange(-10,10.5,0.5)
wrange3 = np.array([steps3,steps3,steps3])
print("The mean error for 10-fold cross validation of the quadratic model is",cross_validate_silly(quadratic_train_data[:,0:3],y_train,2,10,wrange3,silly_loss))


# In[14]:

#Determine best fit quadratic model
X = quadratic_test_data[:,0:3]
y = y_test
steps = np.arange(-10,10.5,0.5)
wrange3 = np.array([steps,steps,steps])
quad_exp = test_ws(X,y,wrange3,silly_loss)
print("The coefficients of the best quadratic model under exponential noise are", quad_exp[1])


# In[15]:

#Empirical loss for training
quadratic_empirical_loss_exp_train = squared_loss(quadratic_train_data[:,0:3],y_train, quad_exp[1])
print("The empirical loss on the 2008 test data with the quadratic fit under exponential noise",quadratic_empirical_loss_exp_train)

#log-likelihood for training
yhat = np.dot(quadratic_train_data[:,0:3],quad_exp[1])
log_likelihood_exp_train = silly_loss(yhat,y_train)
print("The log-likelihood on the 2008 test data with the quadratic fit under exponential noise is", -log_likelihood_exp_train)


# In[16]:

#Empirical loss for test
quadratic_empirical_loss_exp = squared_loss(quadratic_test_data[:,0:3],y_test, quad_exp[1])
print("The empirical loss on the 2009 test data with the quadratic fit under exponential noise",quadratic_empirical_loss_exp)

#log-likelihood for test
yhat = np.dot(quadratic_test_data[:,0:3],quad_exp[1])
log_likelihood_exp = silly_loss(yhat,y_test)
print("The log-likelihood on the 2009 test data with the quadratic fit under exponential noise is", -log_likelihood_exp)


# In[17]:

t = np.arange(0.0, 5.0, 0.01)
s = np.array( quad_exp[1][0] + quad_exp[1][1] * t + quad_exp[1][2] * (t**2))

with sns.axes_style("darkgrid"):
    fig, ax = plt.subplots()
    ax.set_title('Quadratic Fit with Exponential Noise (Training Data)')
    ax.plot(quadratic_train_data[:,1], y_train, 'o', label = 'data')
    ax.plot(t,s)
    ax.legend(['2008 Data', 'Quadratic Fit'], loc='best')
    ax.set(ylim=(0, 10))
    ax.set(xlim=(0, 1.05))
    plt.show()

with sns.axes_style("darkgrid"):
    fig, ax = plt.subplots()
    ax.set_title('Quadratic Fit with Exponential Noise (Test Data)')
    ax.plot(X[:,1], y, 'o', label = 'data')
    ax.plot(t,s)
    ax.legend(['2009 Data', 'Quadratic Fit'], loc='best')
    ax.set(ylim=(0, 10))
    ax.set(xlim=(0, 1.05))
    plt.show()


# In[ ]:



