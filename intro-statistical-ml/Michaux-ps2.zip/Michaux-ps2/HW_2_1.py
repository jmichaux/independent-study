
# coding: utf-8

# Problem 1

# In[150]:

import numpy as np
from scipy.stats import beta
import matplotlib.pyplot as plt
theta_true = 0.7
#Flip a coin 3 times.  Do this 1000 times
coins = np.random.uniform(size=(1000,3)) <=theta #Each row is a series of 3 flips


# In[151]:

theta_MLE_1000 = np.mean(coins,axis=1) #Gives a list of MLE estimates of theta for all 1000 trials
theta_MLE = np.mean(theta_MLE_1000)
average_bias = np.mean(theta_MLE_1000 - theta_true)
print("The ML estimator of theta is",theta_MLE)
print("The bias is",average_bias)


# In[152]:

var = np.mean((theta_MLE_1000 - theta_MLE)**2)
print("The variance is",var)


# In[153]:

mse = np.mean((theta_MLE_1000 - theta_true)**2)
print("The mean squared errord is",mse)


# Problem 2

# In[158]:

thetas = np.linspace(0,1,101)
betas_1_1 = beta.pdf(thetas,1,1)
betas_2_4 = beta.pdf(thetas,2,4)
betas_20_20 = beta.pdf(thetas,20,20)
betas_25_10 = beta.pdf(thetas,25,10)

#plot'n stuff
plt.plot(thetas,betas_1_1)
plt.plot(thetas,betas_2_4)
plt.plot(thetas,betas_20_20)
plt.plot(thetas,betas_25_10)
plt.show()


# In[159]:

theta_MAP_1_1 = (np.sum(coins,axis=1) + 1 - 1) / (3 + 1 + 1 -2)
theta_MAP_2_4 = (np.sum(coins,axis=1) + 2 - 1) / (3 + 2 + 4 -2)
theta_MAP_20_20 = (np.sum(coins,axis=1) + 20 - 1) / (3 + 20 + 20 -2)
theta_MAP_25_10 = (np.sum(coins,axis=1) + 25 - 1) / (3 + 25 + 10 -2)

#average bias
bias_1_1 = np.mean((theta_MAP_1_1 - theta_true))
bias_2_4 = np.mean((theta_MAP_2_4 - theta_true))
bias_20_20 = np.mean((theta_MAP_20_20 - theta_true))
bias_25_10 = np.mean((theta_MAP_25_10 - theta_true))

var_1_1 = np.mean((theta_MAP_1_1 - np.mean(theta_MAP_1_1))**2)
var_2_4 = np.mean((theta_MAP_2_4 - np.mean(theta_MAP_2_4))**2)
var_20_20 = np.mean((theta_MAP_20_20 - np.mean(theta_MAP_20_20))**2)
var_25_10 = np.mean((theta_MAP_25_10 - np.mean(theta_MAP_25_10))**2)


mse_1_1 = np.mean((theta_MAP_1_1 - theta_true)**2)
mse_2_4 = np.mean((theta_MAP_2_4 - theta_true)**2)
mse_20_20 = np.mean((theta_MAP_20_20 - theta_true)**2)
mse_25_10 = np.mean((theta_MAP_25_10 - theta_true)**2)



# In[163]:

print(np.mean(theta_MAP_1_1))
print(np.mean(theta_MAP_2_4))
print(np.mean(theta_MAP_20_20))
print(np.mean(theta_MAP_25_10))


# In[160]:

print(bias_1_1)
print(bias_2_4)
print(bias_20_20)
print(bias_25_10)


# In[161]:

print(var_1_1)
print(var_2_4)
print(var_20_20)
print(var_25_10)


# In[162]:

print(mse_1_1)
print(mse_2_4)
print(mse_20_20)
print(mse_25_10)


# In[ ]:



