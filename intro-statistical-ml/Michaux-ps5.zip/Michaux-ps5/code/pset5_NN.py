
# coding: utf-8

# In[1]:

from __future__ import division, print_function, absolute_import
import glob
import os
import numpy as np
import sys
import h5py
import pdb
from sklearn.feature_extraction.text import CountVectorizer
import io
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix
from sklearn.preprocessing import binarize
from scipy.misc import logsumexp
get_ipython().magic('matplotlib inline')


# In[110]:

def load_data(filename, dataset):
    with h5py.File(filename) as data:
        X = data[dataset]['x'][:].astype(np.float64) / 255
        N = X.shape[0]
        X = X.reshape((N, -1))
        if 'y' in data[dataset]:
            y = data[dataset]['y'][:]
            Y = np.zeros((N, CLASSES))
            Y[np.arange(N), y] = 1
            return X, Y
        else:
            return X



def softmax(Z):
    """
    Z is 2D and a softmax is taken over the second dimension for each sample
    separately.
    """
    Z -= Z.mean(1)[:, np.newaxis]
    expZ = np.exp(Z)
    return expZ / expZ.sum(1)[:, np.newaxis]





def partition(input_data,fold,num_classes):
    #idx = np.where(Y[:,0]>0)[0]
    #np.shape(idx)[0]
    #shuffle indices
    #np.random.shuffle(indices)
    #fold = size of sub-batch
    #num_classes
    final = np.zeros([fold,1], dtype=object)
    partition = np.zeros([num_classes,fold], dtype = object)
    for i in range(num_classes):
        partition[i] = np.array_split(np.where(input_data[:,i]>0)[0],fold)
    for j in range(fold):
        final[j][0] = np.hstack(partition[0:num_classes,j])
    return final


def get_batch(X, Y, iteration):
    """
    Returns a batch, given which iteration it is. Fold is defined
    outside of get_batch. It's a parameter that can be tweaked.
    """
    # YOUR CODE HERE
    # This will return the entire data set each iteration. This is costly, so
    # you should experiment with different way of changing this:
    #return X,Y
    return X[batch_idx[iteration%fold][0]], Y[batch_idx[iteration%fold][0]]
    #return X[iteration%100: iteration%100 + 100,:], X[iteration%fold: iteration%fold + 100,:]


def save_submission(filename, yhats):
    assert np.ndim(yhats) == 1
    id_and_prediction = np.vstack([np.arange(len(yhats)).T, yhats]).T
    np.savetxt(filename, id_and_prediction,
               fmt='%d',
               delimiter=',',
               comments='',
               header='Id,Prediction')


# NETWORK COMPONENTS
# Dense layer
def dense_forward(X, W, b):
    """
    Fully connected layer.

    X: input (N x A)
    W: weights (A x B)
    b: bias (B)
    A: input features
    B: output features

    Returns: output (N x B)
    """
    return np.dot(X, W) + b


# Activation layer
def activation_forward(X):
    """
    Takes input and applies non-linearity elementwise

    X: input (N x A)
    N: samples
    A: input and output feature length

    Returns: output (N x A)
    """
    X[X<0]=0
    return X


def activation_backward(X, output, output_diff):
    """
    Returns gradient of loss with respect to input of non-linearity

    X: input (N x A)
    N: samples
    A: input and output feature length
    output: output (N x A)
    output_diff: output gradients (N x A)

    Returns: input_gradient (N x A)
    """
    # YOUR CODE HERE
    # Currently congruent with the linear activation. If you change
    # activation_forward, you will have to change this as well.
    
    return (X>0) * output_diff



def dense_backward(X, W, b, output, output_diff):
    """
    Returns gradient of loss w.r.t. all three inputs.

    X: input (N x A)
    W: weights (A x B)
    b: bias (B)
    output: outputs (N x B)
    output_diff: output gradients (N x B)

    Returns: tuple with:
    - input gradient w.r.t. X (N x A)
    - input gradient w.r.t. W (A x B)
    - input gradient w.r.t. b (B)
    """
    N = np.size(X,0)
    return (
        np.dot(output_diff,W.T),
        np.dot(X.T, output_diff),
        np.dot(np.ones(N),output_diff)
    )


# Softmax + cross entropy loss layer
def softmax_loss_forward(X, Y):
    """
    Softmax and cross entropy loss layer. Should return a scalar, since it's a
    loss.

    X: input (N x A)
    Y: labels (N x C)
    A: input features
    C: label classes

    Returns: loss (scalar)
    """
    Z = softmax(X)
    return -(Y * np.log(Z)).sum() / len(Y)


def softmax_loss_backward(X, Y, output, output_diff):
    """
    Gradient of loss w.r.t. input (X). Ideally, you should incorporate
    output_diff, but it won't make a difference if you don't, since it will be
    set to 1.

    Note: This function could return the gradient w.r.t Y as well, but we
    won't need it.

    X: input (N x A)
    Y: labels (N x C)
    A: input features
    C: label classes
    output: scalar
    output_diff: scalar

    Returns: input gradient (N x A)
    """
    # YOUR CODE HERE
    # You must define this gradient
    
    return -output*(Y - softmax(X))/len(Y)




# In[213]:

DATASET = 'noisy'
CLASSES = 10
fn = '{}_mnist.h5'.format(DATASET)
X, Y = load_data(fn, '/train')
tX, tY = load_data(fn, '/test')
print('Dataset:', DATASET)
SAMPLES, FEATURES = X.shape


# In[215]:

fn = '{}_mnist.h5'.format(DATASET)

rs = np.random.RandomState(1234)

X, Y = load_data(fn, '/train')
tX, tY = load_data(fn, '/test')

fold = 100
num_classes = 10
batch_idx = partition(Y,fold,num_classes)


SAMPLES, FEATURES = X.shape

train_errors = []
test_errors = []

# NOTE: Feel free to change this.
HIDDEN = 80

# Weight/bias for layer 1
W1 = rs.normal(0, 0.01, size=(X.shape[1], HIDDEN))
b1 = np.zeros(HIDDEN)

# Weight/bias for layer 2
W2 = rs.normal(0, 0.01, size=(HIDDEN, CLASSES))
b2 =  np.zeros(CLASSES)


n_iter = 4000
stepsize = .05
lam1 = 0.0000
lam2 = 0.0

iteration = 0
while True:
    # Get the batch (X_i, Y_i)
    bX, bY = get_batch(X, Y, iteration)

    # Forward pass
    data0 = bX
    data1 = dense_forward(data0, W1, b1)
    data2 = activation_forward(data1)
    data3 = dense_forward(data2, W2, b2)
    data4 = softmax_loss_forward(data3, bY)
    loss = data4

        # Backward pass
    diff4 = 1
    diff3 = softmax_loss_backward(data3, bY, data4, diff4)
    diff2_X, diff2_W, diff2_b = dense_backward(data2, W2, b2, data3, diff3)
    diff1 = activation_backward(data1, data2, diff2_X)
    diff0_X, diff0_W, diff0_b = dense_backward(data0, W1, b1, data1, diff1)

    if iteration % 1000 == 0:
        print('{:8} batch loss: {:.3f}'.format(iteration, loss))

    # YOUR CODE HERE
    # Change this stopping criterion
    if iteration >= 10000:
        break

    # YOUR CODE HERE
    # Update rules for W1, b1, W2 and b2
    W1 += -(stepsize * diff0_W + lam1*W1 )
    b1 += -stepsize * diff0_b 
    W2 += -(stepsize * diff2_W + lam2*W2)
    b2 += -stepsize * diff2_b



    iteration += 1

# Forward pass
def predict(X):
    return dense_forward(activation_forward(dense_forward(X, W1, b1)), W2, b2)

Yhat = predict(X)
tYhat = predict(tX)

train_err = (Yhat.argmax(-1) != Y.argmax(-1)).mean()
test_err = (tYhat.argmax(-1) != tY.argmax(-1)).mean()

print('train error:  {:.2f}%'.format(100 * train_err))
print('test error:   {:.2f}%'.format(100 * test_err))

# Generate a Kaggle submission file using `model`
kX = load_data(fn, '/kaggle')
kYhat = predict(kX)
save_submission('cleansubmission_{}.csv'.format(DATASET), kYhat.argmax(-1))



# In[216]:

plt.matshow(confusion_matrix(np.array(tYhat.argmax(-1)),np.array(tY.argmax(-1))))
plt.colorbar()
plt.ylabel('Truth')
plt.xlabel('Prediction')
plt.title('Noisy')
plt.show()


# In[ ]:



