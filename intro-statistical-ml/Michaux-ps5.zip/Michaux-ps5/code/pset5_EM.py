
# coding: utf-8

# In[1]:

from __future__ import division, print_function, absolute_import
import glob
import os
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
import io
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix
from scipy.misc import logsumexp
get_ipython().magic('matplotlib inline')


# In[2]:

def save_submission(filename, yhats):
    """
    Save Kaggle competition submission file.

    Parameters
    ----------
    filename : str
        Name of submission file to write.
    yhats : array
        Array of ones (spam) and zeros (ham).
    """
    assert np.ndim(yhats) == 1
    assert set(np.unique(yhats)) == {0, 1}, 'Prediction must be either 0 or 1'
    assert len(yhats) == 300, 'Must have 300 predictions'
    id_and_prediction = np.vstack([np.arange(len(yhats)).T, yhats]).T
    np.savetxt(filename, id_and_prediction,
               fmt=['%03d', '%d'],
               delimiter=',',
               comments='',
               header='Email,Spam')


def load_dictionary(dict_fname):
    """
    Loads a list of tokens from a file.

    Parameters
    ----------
    dict_fname: str
        Filename of dictionary.

    Returns
    -------
    dictionary : list
        List of strings with tokens.
    """
    # Load dictionary
    with open(dict_fname) as f:
        return [s.strip() for s in f]


def parse_directory(dname, dictionary):
    """
    Load directory of emails and return an array with counts.

    Parameters
    ----------
    dname : str
        Path to dictionary of .eml files.
    dictionary : list of strings
        List of strings with dictionary words. You can use the function
        `load_dictionary` to load this list.

    Returns
    -------
    X : array
        2D numpy array of size `(N, D)`, where `N` is the number of samples
        (emails) and `D` is the size of the dictionary you put in. The value
        ``X[n, d]`` specifies the number of times the token `d` appeared in
        email `n`.
    """

    # List of filenames of all emails in the directory
    fns = sorted(glob.glob(os.path.join(dname, '*.eml')))

    # Build tokenizer and initialize with our dictionary
    vectorizer = CountVectorizer(token_pattern=r'[a-z_@]+')
    vectorizer.fit_transform(dictionary)

    emails = []
    for fn in fns:
        with io.open(fn, encoding='iso-8859-1') as f:
            emails.append(f.read())

    X = vectorizer.transform(emails)

    # X is a scipy sparse matrix, which is great for storing large matrices
    # with many zero entries. Our data is not that big, so we will convert it
    # back to regular numpy arrays to make it more familiar to work with.
    # We are also binarizing it to {0, 1}.
    return (np.asarray(X.todense()) >= 1).astype(np.int64)


# In[3]:

hamD = '/Users/JM/Desktop/TTIC_31020/HW_5/data/trainHam'
spamD = '/Users/JM/Desktop/TTIC_31020/HW_5/data/trainSpam'
testD = '/Users/JM/Desktop/TTIC_31020/HW_5/data/test'
dictname = '/Users/JM/Desktop/TTIC_31020/HW_5/data/dictionary.txt'
dictionary = load_dictionary(dictname)
hamCounts = parse_directory(hamD,dictionary)
spamCounts = parse_directory(spamD,dictionary)
testCounts = parse_directory(testD,dictionary)


# In[65]:

X_0.shape


# In[66]:

#ham
X_0 = hamCounts[0:3501,:]


# In[67]:

k=5
epsilon = 0.0005

np.random.shuffle(X_0)
pye_0 = np.ones(k)/k
mu_temp_0 = np.array_split(X_0,k)
mu_0 = np.mean(mu_temp_0[0],axis=0)

for i in range(1,k):
    mu_temp2_0 = np.mean(mu_temp_0[i],axis=0)
    mu_0 = np.vstack((mu_0,mu_temp2_0))
mu_0 = np.where(mu_0<(1-epsilon),mu_0,0)
mu_0 = np.where(mu_0>epsilon,mu_0,0)
mu_0 = mu_0 + epsilon*(mu_0<epsilon) + (1-epsilon)*(mu_0>(1-epsilon))


# In[87]:

#E-step
numer_0 = np.dot(X_0,np.log(mu_0).T) + np.dot((1-X_0),np.log(1-mu_0).T) + np.log(pye_0) 
denom_0 = np.tile(logsumexp(numer_0,axis=1),(k,1))
gamma_0 = np.exp(numer_0 - denom_0.T)

#Calculate N_k
#N_k = np.sum(gamma>=0.5,axis=0)
N_k_0 = np.sum(gamma_0,axis=0)

#M-step
mu_0 = np.dot(gamma_0.T,X_0)/N_k_0[:,None]
mu_0 = np.where(mu_0<(1-epsilon),mu_0,0)
mu_0 = np.where(mu_0>epsilon,mu_0,0)
mu_0 = mu_0 + epsilon*(mu_0<epsilon) + (1-epsilon)*(mu_0>(1-epsilon))
pye_0 = N_k_0/np.shape(X_0)[0]

print(pye_0)


# In[88]:

spamCounts.shape


# In[89]:

#spam
X_1 = spamCounts[0:1641,:]


# In[90]:

k=5
epsilon = 0.0005
#X = spamCounts
np.random.shuffle(X_1)
pye_1 = np.ones(k)/k
mu_temp_1 = np.array_split(X_1,k)
mu_1 = np.mean(mu_temp_1[0],axis=0)

for i in range(1,k):
    mu_temp2_1 = np.mean(mu_temp_1[i],axis=0)
    mu_1 = np.vstack((mu_1,mu_temp2_1))
mu_1 = np.where(mu_1<(1-epsilon),mu_1,0)
mu_1 = np.where(mu_1>epsilon,mu_1,0)
mu_1 = mu_1 + epsilon*(mu_1<epsilon) + (1-epsilon)*(mu_1>(1-epsilon))


# In[102]:

#E-step
numer_1 = np.dot(X_1,np.log(mu_1).T) + np.dot((1-X_1),np.log(1-mu_1).T) + np.log(pye_1) 
denom_1 = np.tile(logsumexp(numer_1,axis=1),(k,1))
gamma_1 = np.exp(numer_1 - denom_1.T)

#Calculate N_k
#N_k = np.sum(gamma>=0.5,axis=0)
N_k_1 = np.sum(gamma_1,axis=0)

#M-step
mu_1 = np.dot(gamma_1.T,X_1)/N_k_1[:,None]
mu_1 = np.where(mu_1<(1-epsilon),mu_1,0)
mu_1 = np.where(mu_1>epsilon,mu_1,0)
mu_1 = mu_1 + epsilon*(mu_1<epsilon) + (1-epsilon)*(mu_1>(1-epsilon))
pye_1 = N_k_1/np.shape(X_1)[0]

print(pye_1)


# In[103]:

new_pye = np.hstack((pye_0,pye_1))
new_mu = np.vstack((mu_0,mu_1))
test = np.dot(testCounts,np.log(new_mu).T) + np.dot((1-testCounts),np.log(1-new_mu).T)


# In[104]:

out = test.argmax(-1) // k


# In[45]:

save_submission('test_EM_3.txt',out)


# In[ ]:

#Testing the ground truth


# In[112]:

ham_test = hamCounts[3501:3600,:] 
spam_test = spamCounts[1641:1740,:]
testData = np.vstack((spam_test,ham_test))
test = np.dot(testData,np.log(new_mu).T) + np.dot((1-testData),np.log(1-new_mu).T)
out = test.argmax(-1) // k


# In[119]:

truth = np.hstack((np.ones(np.shape(spam_test)[0]),np.zeros(np.shape(ham_test)[0])))
plt.matshow(confusion_matrix(np.array(out),np.array(truth)))
plt.colorbar()
plt.ylabel('Truth')
plt.xlabel('Prediction')
plt.show()


# In[126]:

sum(out[100:])


# In[123]:

out


# In[ ]:



