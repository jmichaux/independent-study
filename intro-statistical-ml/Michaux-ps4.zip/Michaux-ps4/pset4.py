
# coding: utf-8

# In[ ]:

get_ipython().magic('pwd')


# In[171]:

from __future__ import division, print_function, absolute_import
import glob
import os
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix
get_ipython().magic('matplotlib inline')


# In[ ]:

def load_dictionary(dict_fname):
    """
    Loads a list of tokens from a file.

    Parameters
    ----------
    dict_fname: str
        Filename of dictionary.

    Returns
    -------
    dictionary : list
        List of strings with tokens.
    """
    # Load dictionary
    with open(dict_fname) as f:
        return [s.strip() for s in f]


def parse_directory(dname, dictionary):
    """
    Load directory of emails and return an array with counts.

    Parameters
    ----------
    dname : str
        Path to dictionary of .eml files.
    dictionary : list of strings
        List of strings with dictionary words. You can use the function
        `load_dictionary` to load this list.

    Returns
    -------
    X : array
        2D numpy array of size `(N, D)`, where `N` is the number of samples
        (emails) and `D` is the size of the dictionary you put in. The value
        ``X[n, d]`` specifies the number of times the token `d` appeared in
        email `n`.
    """

    # List of filenames of all emails in the directory
    fns = sorted(glob.glob(os.path.join(dname, '*.eml')))

    # Build tokenizer and initialize with our dictionary
    vectorizer = CountVectorizer(token_pattern=r'[a-z_@]+')
    vectorizer.fit_transform(dictionary)

    emails = []
    for fn in fns:
        with open(fn, encoding='iso-8859-1') as f:
            emails.append(f.read())

    X = vectorizer.transform(emails)

    # X is a scipy sparse matrix, which is great for storing large matrices
    # with many zero entries. Our data is not that big, so we will convert it
    # back to regular numpy arrays to make it more familiar to work with.
    # We are also binarizing it to {0, 1}.
    return (np.asarray(X.todense()) >= 1).astype(np.int64)


def save_submission(filename, yhats):
    """
    Save Kaggle competition submission file.

    Parameters
    ----------
    filename : str
        Name of submission file to write.
    yhats : array
        Array of ones (spam) and zeros (ham).
    """
    assert np.ndim(yhats) == 1
    assert set(np.unique(yhats)) == {0, 1}, 'Prediction must be either 0 or 1'
    assert len(yhats) == 300, 'Must have 300 predictions'
    id_and_prediction = np.vstack([np.arange(len(yhats)).T, yhats]).T
    np.savetxt(filename, id_and_prediction,
               fmt=['%03d', '%d'],
               delimiter=',',
               comments='',
               header='Email,Spam')


# In[ ]:

hamD = '/Users/JM/Desktop/TTIC_31020/HW_4/data/trainHam'
spamD = '/Users/JM/Desktop/TTIC_31020/HW_4/data/trainSpam'
testD = '/Users/JM/Desktop/TTIC_31020/HW_4/data/test'
dictname = '/Users/JM/Desktop/TTIC_31020/HW_4/data/dictionary.txt'
dictionary = load_dictionary(dictname)
hamCounts = parse_directory(hamD,dictionary)
spamCounts = parse_directory(spamD,dictionary)
testCounts = parse_directory(testD,dictionary)


# In[196]:

#First pass using Laplace Smoothing, which is the same as Beta with alpha = beta = 2
alpha, beta = 2,2
phi_y = (np.shape(spamCounts)[0] + alpha - 1) / (np.shape(spamCounts)[0] + np.shape(hamCounts)[0]+ alpha + beta - 2)
phi_spam = (np.sum(spamCounts,axis=0) + alpha - 1) / (np.shape(spamCounts)[0] +alpha + beta - 2)
phi_ham = (np.sum(hamCounts,axis=0) +alpha - 1) / (np.shape(hamCounts)[0] +alpha + beta - 2)


# In[197]:

a = testCounts*phi_ham
b = testCounts*phi_spam


# In[198]:

a[np.nonzero(a)] = np.log(a[np.nonzero(a)])
b[np.nonzero(b)] = np.log(b[np.nonzero(b)])


# In[212]:

out_a = np.sum(a,axis=1) + np.log(1-phi_y)
out_b = np.sum(b,axis=1) + np.log(phi_y)


# In[213]:

out = ((out_b - out_a) > 0) + 0


# In[123]:

save_submission('test_5.txt',out)


# In[211]:

np.shape(out_3)


# In[215]:

#Testing on various subsets of training data
error = []
alphas = [2]
betas = [2]
for alpha in alphas:
    for beta in betas:
        phi_y = (np.shape(spamCounts)[0] + alpha - 1) / (np.shape(spamCounts)[0] + np.shape(hamCounts)[0]+ alpha + beta - 2)
        phi_spam = (np.sum(spamCounts,axis=0) + alpha - 1) / (np.shape(spamCounts)[0] +alpha + beta - 2)
        phi_ham = (np.sum(hamCounts,axis=0) +alpha - 1) / (np.shape(hamCounts)[0] +alpha + beta - 2)


        ham_test = hamCounts 
        spam_test = spamCounts

        testData = np.vstack((spam_test,ham_test))

        a = testData*phi_ham
        b = testData*phi_spam

        a[np.nonzero(a)] = np.log(a[np.nonzero(a)])
        b[np.nonzero(b)] = np.log(b[np.nonzero(b)])

        out_a = np.sum(a,axis=1) + np.log(1-phi_y)
        out_b = np.sum(b,axis=1) + np.log(phi_y)


        out_3 = ((out_b - out_a) > 0) + 0

        spam_errors = (np.shape(spam_test)[0] - np.sum(out_3[0:np.shape(spam_test)[0]]))/ np.shape(spam_test)[0]
        ham_errors = (np.sum(out_3[np.shape(spam_test)[0]:]))/ np.shape(ham_test)[0]
        print(spam_errors+ham_errors, alpha,beta)


# In[217]:

truth = np.hstack((np.ones(np.shape(spam_test)[0]),np.zeros(np.shape(ham_test)[0])))
plt.matshow(confusion_matrix(np.array(out_3),np.array(truth)))
plt.colorbar()
plt.ylabel('Truth')
plt.xlabel('Prediction')
plt.show()


# In[ ]:



