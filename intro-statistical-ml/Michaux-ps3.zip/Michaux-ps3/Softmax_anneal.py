
# coding: utf-8

# In[ ]:

import numpy as np
import sys
import h5py
import pdb
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix
get_ipython().magic('matplotlib inline')

CLASSES = 10
#DATASET = 'clean'
#DATASET = 'noisy'

def load_data(filename, dataset):
    try:
        with h5py.File(filename) as data:
            X = data[dataset]['x'][:].astype(np.float64) / 255
            N = X.shape[0]
            X = X.reshape((N, -1))
            if 'y' in data[dataset]:
                y = data[dataset]['y'][:]
                Y = np.zeros((N, CLASSES))
                Y[np.arange(N), y] = 1
                return X, Y
            else:
                return X
    except KeyError:
        print('ERROR: Please place the {} in the same directory as pset3.py'.format(filename))
        sys.exit(1)


def test(X, Y, model):
    return predict(X, model).argmax(-1) == Y.argmax(-1)


def error_rate(X, Y, model):
    return 1 - test(X, Y, model).mean()


def save_submission(filename, yhats):
    assert np.ndim(yhats) == 1
    id_and_prediction = np.vstack([np.arange(len(yhats)).T, yhats]).T
    np.savetxt(filename, id_and_prediction,
               fmt='%d',
               delimiter=',',
               comments='',
               header='Id,Prediction')


def softmax(Z):
    """
    Z is 2D and a softmax is taken over the second dimension for each sample
    separately.
    """
    # Change the dynamic range before normalization, to avoid precision errors
    Z -= Z.max(1)[:, np.newaxis]
    expZ = np.exp(Z)
    return expZ / expZ.sum(1)[:, np.newaxis]


def predict(X, model):
    """
    Evaluate the soft predictions of the model.
    """
    return softmax(np.dot(X, model['weight']) + model['bias'])


def calc_loss(X, Y, model):
    """
    Evaluate the loss (without regularization penalty).
    """
    Z = predict(X, model)
    return -(Y * np.log(Z)).sum() / len(Y)


def gradient_weight(X, Y, model):
    """
    Gradient of the regularized loss with respect to the weights.
    """
    W = model['weight']
    b = model['bias']
    weight_decay = model['weight_decay']
    
    # YOUR CODE HERE
    # Write the gradient with respect to the weights.
    # The following line is just a placeholder
    return (np.transpose(X).dot(softmax(np.dot(X, W) + b) - Y))/ len(Y) + weight_decay * W


def gradient_bias(X, Y, model):
    """
    Gradient of the (regularized) loss with respect to the bias.
    """
    W = model['weight']
    b = model['bias']
    weight_decay = model['weight_decay']

    # YOUR CODE HERE
    # Write the gradient with respect to the bias
    # The following line is just a placeholder
    return np.sum((softmax(np.dot(X, W)) + b) - Y,axis=0) / len(Y)

def partition(input_data,fold,num_classes):
    #idx = np.where(Y[:,0]>0)[0]
    #np.shape(idx)[0]
    #shuffle indices
    #np.random.shuffle(indices)
    #fold = size of sub-batch
    #num_classes
    final = np.zeros([fold,1], dtype=object)
    partition = np.zeros([num_classes,fold], dtype = object)
    for i in range(num_classes):
        partition[i] = np.array_split(np.where(input_data[:,i]>0)[0],fold)
    for j in range(fold):
        final[j][0] = np.hstack(partition[0:num_classes,j])
    return final


def get_batch(X, Y, iteration):
    """
    Returns a batch, given which iteration it is. Fold is defined
    outside of get_batch. It's a parameter that can be tweaked.
    """
    # YOUR CODE HERE
    # This will return the entire data set each iteration. This is costly, so
    # you should experiment with different way of changing this:
    #return X,Y
    return X[batch_idx[iteration%fold][0]], Y[batch_idx[iteration%fold][0]]
    #return X[iteration%100: iteration%100 + 100,:], X[iteration%fold: iteration%fold + 100,:]
    


    


  


# In[ ]:

#Load the data set
DATASET = 'noisy'
CLASSES = 10
fn = '{}_mnist.h5'.format(DATASET)
X, Y = load_data(fn, '/train')
tX, tY = load_data(fn, '/test')
print('Dataset:', DATASET)
SAMPLES, FEATURES = X.shape


# In[ ]:

#Set up for mini-batching
fold = 10
num_classes = 10
batch_idx = partition(Y,fold,num_classes)


# In[ ]:

train_error_vec = []
test_error_vec=[]
for weight_decay in [0.00005]:
    for mu in [1]:

        learning_rate = .01    
        mu = 1
        #Momentum
        v = 0

        # Weight decay
        #weight_decay = 0.005
    

    
        # Random number generator for initializing the weights
        rs = np.random.RandomState(2341)

        model = {
            # Initialization of model (you can change this if you'd like)
            'weight': rs.normal(scale=0.01, size=(FEATURES, CLASSES)),
            'bias': np.zeros(CLASSES),
            'weight_decay': weight_decay
            }
    
    

        model_temp = {
            # Initialization of model (you can change this if you'd like)
            'weight': rs.normal(scale=0.01, size=(FEATURES, CLASSES)),
            'bias': np.zeros(CLASSES),
            'weight_decay': weight_decay
            }

    

    
        iteration = 0
        while True:
            # Get the batch (X_i, Y_i)
            bX, bY = get_batch(X, Y, iteration)
        

            if iteration % 500 == 0:
                loss = calc_loss(bX, bY, model)
                print('{:8} batch loss: {:.6f}'.format(iteration, loss))

            loss = calc_loss(bX, bY, model)
            if np.isnan(loss):
                pdb.set_trace()
            
        
        # Change this stopping criterion
            if iteration >= 10000:
                break

        # Gradient calculation
            grad_w = gradient_weight(bX, bY, model)
            grad_b = gradient_bias(bX, bY, model)

            #if iteration%500==0:
            #    learning_rate = 0.5*learning_rate        
            #model['weight'] += -learning_rate * grad_w 
            #model['bias'] += -learning_rate * grad_b  
            mu = 1 - 3/(iteration+5)
            v1 = mu * v - learning_rate * grad_w
            v2 = mu * v - learning_rate * grad_b
            model['weight'] += v1
            model['bias'] += v2
            if np.isnan(model['weight']).any() or np.isnan(model['bias']).any():
                pdb.set_trace()  
        
            iteration += 1

        train_error_vec.append(error_rate(X, Y, model))
        test_error_vec.append(error_rate(tX, tY, model))
    train_err = error_rate(X, Y, model)
    test_err = error_rate(tX, tY, model)

print('train error:  {:.2f}%'.format(100 * train_err))
print('test error:   {:.2f}%'.format(100 * test_err))

# Generate a Kaggle submission file using `model`
kX = load_data(fn, '/kaggle')
Yhat = predict(kX, model)
save_submission('submission_{}.csv'.format(DATASET), Yhat.argmax(-1))



# In[ ]:

clean_model = model


# In[ ]:

clean_loss = [2.295108,0.808407,0.622735,0.546354,0.502469,0.473045,0.451486,0.434756,0.421241,0.409994,0.400421,0.392124,0.384828,0.378334,0.372496,0.367203,0.362368,0.357924,0.353816,0.350000,0.346440]


# In[ ]:

clean_batch_number = [0,500 ,1000 ,1500 ,2000 ,2500 ,3000 ,3500 ,4000 ,4500 ,5000 ,5500,6000 ,6500 ,7000 ,7500 ,8000 ,8500 ,9000 ,9500 ,10000 ]


# In[ ]:

fig, ax = plt.subplots()
ax.plot(clean_batch_number,clean_loss)
plt.xlabel('iteration')
plt.ylabel('loss')
plt.title('Clean Data')


# In[ ]:

A = clean_model['weight'][:,9].reshape(24,24)
fig, ax = plt.subplots()
ax.imshow(A)





# In[ ]:

#Plot the loss
fig, ax = plt.subplots()
ax.plot(clean_batch_number,noisy_loss)
plt.xlabel('iteration')
plt.ylabel('loss')
plt.title('Noisy Data')


# In[ ]:

Y_new_clean = predict(tX,clean_model)
y_clean_test = []
y_clean_pred = []
for i in range(1000):
    y_clean_test.append(np.argmax(tY[i,:],axis=0))
    y_clean_pred.append(np.argmax(Y_new[i,:],axis=0))
plt.matshow(confusion_matrix(np.array(y_clean_test),np.array(y_clean_pred)))
plt.colorbar()
plt.ylabel('Test')
plt.xlabel('Prediction')


# Noisy

# In[ ]:

B = noisy_model['weight'][:,9].reshape(24,24)
fig, ax = plt.subplots()
ax.imshow(B)


# In[ ]:

fig, ax = plt.subplots()
ax.imshow(A)
plt.show()


# In[ ]:

noisy_model = model


# In[ ]:

noisy_loss = [2.300413,1.418555,1.086272,0.925311,0.830753,0.767990,0.722814,0.688394,0.661052,0.638630,0.619782,0.603621,0.589539,0.577104,0.566002,0.555994,0.546901,0.538582,0.530924,0.523837,0.517249]


# In[ ]:

Y_new_noisy = predict(tX,noisy_model)
y_noisy_test = []
y_noisy_pred = []
for i in range(1000):
    y_noisy_test.append(np.argmax(tY[i,:],axis=0))
    y_noisy_pred.append(np.argmax(Y_new[i,:],axis=0))
plt.matshow(confusion_matrix(np.array(y_noisy_test),np.array(y_noisy_pred)))
plt.colorbar()
plt.ylabel('Test')
plt.xlabel('Prediction')

