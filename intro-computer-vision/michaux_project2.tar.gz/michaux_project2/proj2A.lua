require 'torch'
function new_circuit()
	local c ={}
	c.inputs = {}
	c.count =1
	return c
	end

count = 1

function new_unit()
	local u ={}
	u.users = {}
	u.inputs = {}
	u.index = count
	count = count + 1
	u.initialized = false
	function u.init()
		if not u.initialized
		 then u.initialized = true
			u.grad = 0
			print(string.format('dx%d = %d', u.index, u.grad))
			u.backprop_done =false
	 		for i = 1,table.getn(u.inputs) do
				u.inputs[i].init()
			end
		end
	end
	function u.value()
	if not u.initialized then
		return u.value_cache
	 else
		u.value_cache = u.compute_value()
	 	u.initialized = false
		return u.value_cache
	 end
	end
	function u.backprop()
	if not u.backprop_done
		 then for i =1,table.getn(u.users) do u.users[i].backprop() end
			u.do_backprop()
			u.backprop_done = true
		end
		 end
	return u
	end

function make_input(c)
	local x = new_unit()
	x.input_value = torch.random()/(2^32) - .5
	table.insert(c.inputs,x)
	function x.compute_value() return x.input_value end
	function x.do_backprop() end
	return x
	end

function declare_user(y,x)
	table.insert(x.users,y)
	table.insert(y.inputs,x)
	end
	
function make_square(x)
	local y = new_unit()
	declare_user(y,x)
	function y.compute_value()
		local xval = x.value()
		print(string.format('x%d = x%d^2', y.index, x.index))
		return xval^2
	end
	function y.do_backprop()
		x.grad = x.grad +(y.grad * 2 * x.value())
		print(string.format('dx%d += dx%d * 2 * x%d', x.index, y.index, x.index))
	end
	return y
end

function make_sum(x1, x2)
	local y = new_unit()
	declare_user(y, x1)
	declare_user(y, x2)
	function y.compute_value()
		local sum = x1.value() + x2.value()
		print(string.format('x%d = x%d + x%d', y.index, x1.index, x2.index))
		return sum
	end
	function y.do_backprop()
		x1.grad = x1.grad + y.grad
		x2.grad = x2.grad + y.grad
		print(string.format('dx%d += dx%d', x1.index, y.index))
		print(string.format('dx%d += dx%d', x2.index, y.index))
	end
	return y
end

function make_sin(x)
	local y = new_unit()
	declare_user(y,x)
	function y.compute_value()
		local xval = x.value()
		print(string.format('x%d = sin(x%d)', y.index, x.index))
		return math.sin(xval)
	end
	function y.do_backprop()
		x.grad = x.grad +(y.grad * math.cos(x.value()))
		print(string.format('dx%d += dx%d * cos(x%d)', x.index, y.index, x.index))
	end
	return y
end

function make_product(x1, x2)
	local y = new_unit()
	declare_user(y, x1)
	declare_user(y, x2)
	function y.compute_value()
		local prod = x1.value()*x2.value()
		print(string.format('x%d = x%d * x%d',y.index, x1.index, x2.index))
		return prod
	end
	function y.do_backprop()
		x1.grad = x2.value()*y.grad
		x2.grad = x1.value()*y.grad
		print(string.format('dx%d += dx%d*x%d', x1.index, y.index, x2.index))
		print(string.format('dx%d += dx%d*x%d', x2.index, y.index, x1.index))
	end
	return y
end

function make_max(x1, x2)
	local y = new_unit()
	declare_user(y, x1)
	declare_user(y, x2)
	function y.compute_value()
		local x1Val = x1.value()
		local x2Val = x2.value()
		print(string.format('x%d = max(x%d, x%d)', y.index, x1.index, x2.index))
		if x1Val >= x2Val then
			return x1.value()
		else
			return x2.value() 
		end
	end
	function y.do_backprop()
		if x1.value() >= x2.value() then
			x1.grad = x1.grad + y.grad
			x2.grad = x2.grad
		else
			x1.grad = x1.grad
			x2.grad = x2.grad + y.grad
		end
		print(string.format('if(x%d > x%d) dx%d += dx%d; else dx%d += dx%d', x1.index, x2.index, x1.index, y.index, x2.index, y.index))
	end
	return y
end


function make_square_circuit()
 c = new_circuit()
 c.output = make_square(make_input(c))
 return c
end

backprop = {lr = .1, N = 10}

function backprop.minimize(c)
	for i = 1,backprop.N do
		c.output.init();
		for i =1,table.getn(c.inputs) do
			-- print(string.format('input %d = %f',i,c.inputs[i].input_value))
		end
	 	-- print(string.format('circuit value = %f',c.output.value()))
	 	c.output.value()
	 	c.output.grad = 1
		print(string.format('dx%d = %d', c.output.index, c.output.grad))
		for i = 1,table.getn(c.inputs) do
		 local x = c.inputs[i];
		 x.backprop();
		 x.input_value = x.input_value - backprop.lr * x.grad
		end
	end
end

function make_deep_circuit()
	count = 1
	c = new_circuit()
	local x1 = make_input(c)
	local x2 = make_input(c)
	local u1 = make_sum(x1,make_sin(x2))
	local u2 = make_sum(u1,make_square(u1))
	local u3 = make_product(u1,u2)
	c.output = make_max(u2, u3)
	return c
end

function test()
	-- backprop.minimize(make_square_circuit())
	backprop.N = 1
	backprop.minimize(make_deep_circuit())
end
