-- This code computes the mean IOU accuracy on the validation set for each class
-- Your code goes here 
IOU = torch.Tensor(1,numClasses)
for i =1,numClasses do
	local val_true = valData.labels:select(2,i)
	local val_neg = torch.eq(val_true,0)
	local out_true = torch.eq(output_labels:select(2,i),1)
	local out_neg = torch.eq(output_labels:select(2,i),0)

	local TP = torch.eq(out_true + val_true,2):sum()
	local FP = torch.eq(out_true + val_neg,2):sum()
	local FN = torch.eq(out_neg + val_true,2):sum()
	IOU[1][i] = TP / (TP + FP + FN)
end
meanIOU = IOU:mean()
