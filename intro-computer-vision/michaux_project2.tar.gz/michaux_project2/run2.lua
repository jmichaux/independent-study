require 'torch'
require 'cutorch'
require 'cunn'
require 'cudnn'
require 'image'

torch.setdefaulttensortype('torch.FloatTensor')

classNames = {};classNames[1] = 'aeroplane';classNames[2] = 'bicycle';classNames[3] = 'bird';classNames[4] = 'boat';classNames[5] = 'bottle';
classNames[6] = 'bus';classNames[7] = 'car';classNames[8] = 'cat';classNames[9] = 'chair';classNames[10] = 'cow';classNames[11] = 'diningtable';classNames[12] = 'dog';
classNames[13] = 'horse';classNames[14] = 'motorbike';classNames[15] = 'person';classNames[16] = 'pottedplant';classNames[17] = 'sheep';classNames[18] = 'sofa';classNames[19] = 'train';classNames[20] = 'tvmonitor';


cmd = torch.CmdLine()
cmd:option('-numClasses', 20,'enter number of classes' )
cmd:option('-classID', 5, 'enter max number of epochs')
cmd:option('-maxEpochs', 10, 'enter max number of epochs')
cmd:option('-classWeight', -1, 'enter class weight')
cmd:option('-backgroundWeight', 1, 'enter background wieght')
cmd:option('-learningRate', 1e-4, 'enter learning rate')
cmd:option('-batchSize', 30, 'enter batch size')
--cmd:option('-initialize',1,'initialize hidden unit')
cmd:option('-weightDecay', 1e-2,'enter weight decay')
cmd:option('-momentum',0.95,'enter momentum')
cmd:option('-dataType', 'cuda', 'enter something')
cmd:option('-FineTuneAlexNet',0,'fine tune AlexNet')
cmd:option('-BatchNorm', 0, 'do you want to try batch normalization')
cmd:option('-saveflag', true, 'enter saveflag')
cmd:option('-save', 'results2', 'enter something') --name of the directory


params = cmd:parse(arg)
--params = {}; params.save = 'problem_2_2a';params.saveflag = true;
numClasses = params.numClasses
--classID = params.classID
maxEpochs = params.maxEpochs
backgroundWeight = params.backgroundWeight
classWeight = params.classWeight
dataType = params.dataType
FineTuneAlexNet = params.FineTuneAlexNet
BatchNorm = params.BatchNorm

--load the mean image


 -- load training data
subset = 'train'
dofile('Dataset_jm.lua')
 --
 --  --load validation data
subset = 'val'
dofile('Dataset_jm.lua')
 --  local valIdentifier = s
 --
 --  --load test data
subset = 'test'
dofile('Dataset_jm.lua')
 --  local testIdentifier = s
 --
 --  --change to cuda
 if dataType == 'cuda' then
	valData.data = valData.data:cuda()
	valData.labels = valData.labels:cuda()
	testData.data = testData.data:cuda()
end


dofile('Training_jm.lua')
if FineTuneAlexNet == 1 then
	local filePath = '/share/project/vision-winter16/AlexNet/ilsvrc_2012_mean.t7';
	mean_pix = torch.load(filePath).img_mean:transpose(3,1) 
	mean_im = image.scale(mean_pix,227, 227, 'bilinear'):float()
end
--if FineTuneAlexNet == true then
--	model:evaluate()
--	output_labels = torch.Tensor(valData:size(),numClasses):zero():cuda()
        --load images in minibatches of size 30
--	for k = 1,valData:size() do
--    local im_temp_1 = image.load(valData.imlist[k]) --This isn't good because we will write over imlist
--	local im_temp_2 = image.scale(im_temp_1,227,227,'bilinear')*255
--	local im_temp_3 = im_temp_2:index(1,torch.LongTensor{3,2,1}):float()
--	im_temp_4 = im_temp_3 - mean_im
--	output = model:forward(im_temp_4:cuda()):gt(0.5)
--	output_labels[{k,{}}] = output
--	end
--dofile('computeMeanIOU.lua')
--print(meanIOU)
--end
epochIOU = torch.Tensor(1,20) + 1
local bestEpoch = 0
keptModel = 0
local maxIOU = 0
inc = 1
for j = 1,maxEpochs do
     
	if j % 10  == 0 then
    	opt.learningRate = opt.learningRate/10
	end
	train()
	if FineTuneAlexNet == 1 then
		if j %10 == 0 then 
			model:evaluate()
	  		output_labels = torch.Tensor(valData:size(),numClasses):zero():cuda()  
	  	--load images in minibatches of size 30
	  
			for z = 1,valData:size(),opt.batchSize  do
	  			counts = 0
				val_inputs = torch.Tensor(math.min(z+opt.batchSize,valData:size()+1)-z,3,227,227):zero()
				for k = z,math.min(z+opt.batchSize-1,valData:size()) do
					counts = counts+1
					local im_temp_1 = image.load(valData.imlist[k]) --This isn't good because we will write over imlist
           		local im_temp_2 = image.scale(im_temp_1,227,227,'bilinear')*255
					local im_temp_3 = im_temp_2:index(1,torch.LongTensor{3,2,1}):float()
            		local im_temp_4 = im_temp_3 - mean_im
					val_inputs[{counts,{},{},{}}] = im_temp_4
				end
          	local output = model:forward(val_inputs:cuda()):gt(0.5)
				output_labels[{{z,z+val_inputs:size(1) - 1},{}}] = output
	  		end
            dofile('computeMeanIOU.lua')
			print(meanIOU)
			if maxIOU < meanIOU then
				maxIOU = meanIOU
				keptModel = model
			end
	    end
	else
		model:evaluate()
		output_labels = model:forward(valData.data):gt(0.5)
		dofile('computeMeanIOU.lua')
		print(meanIOU)
		if maxIOU < meanIOU then
			maxIOU = meanIOU
			keptModel = model
		end
		--print(output)
      	--dofile('computeMeanIOU.lua') --this should give the mean IOU
      	--print(meanIOU)
		--epochIOU[{1,inc}] = meanIOU
		--inc = inc + 1
	end 

end

--Saving a bunch of stuff
keptModel = model
if params.saveflag==true then
	dofile('savePascal.lua')
	if params.save == 'problem_2_1' then
		keptModel:evaluate()
		classValidation = keptModel:forward(valData.data:cuda())  -- run validation 
		for n = 1,numClasses do
		savePascal('val',classValidation[{{},n}], n ,params.save)
		end
	end

	if params.save == 'problem_2_2a' or 'problem_2_2b' then
		keptModel:evaluate()
		val_predictions = torch.Tensor(valData:size(),numClasses):zero():cuda()
		for z = 1,valData:size(),opt.batchSize  do
            counts = 0
            val_inputs = torch.Tensor(math.min(z+opt.batchSize,valData:size()+1)-z,3,227,227):zero()
            for k = z,math.min(z+opt.batchSize-1,valData:size()) do
            	counts = counts+1
                local im_temp_1 = image.load(valData.imlist[k]) --This isn't good because we will write over imlist
                local im_temp_2 = image.scale(im_temp_1,227,227,'bilinear')*255
                local im_temp_3 = im_temp_2:index(1,torch.LongTensor{3,2,1}):float()
                local im_temp_4 = im_temp_3 - mean_im
                val_inputs[{counts,{},{},{}}] = im_temp_4
             end
             local output = model:forward(val_inputs:cuda())
             val_predictions[{{z,z+val_inputs:size(1) - 1},{}}] = output
        end		
		for n = 1,numClasses do
			savePascal('val',val_predictions[{{},n}], n ,params.save)
		end
	        
         test_predictions = torch.Tensor(testData:size(),numClasses):zero():cuda()
         for z = 1,testData:size(),opt.batchSize  do
             counts = 0
             test_inputs = torch.Tensor(math.min(z+opt.batchSize,testData:size()+1)-z,3,227,227):zero()
             for k = z,math.min(z+opt.batchSize-1,testData:size()) do
             	counts = counts+1
                local im_temp_1 = image.load(testData.imlist[k]) --This isn't good because we will write over imlist
                local im_temp_2 = image.scale(im_temp_1,227,227,'bilinear')*255
                local im_temp_3 = im_temp_2:index(1,torch.LongTensor{3,2,1}):float()
                local im_temp_4 = im_temp_3 - mean_im
                test_inputs[{counts,{},{},{}}] = im_temp_4
             end
             local output = model:forward(test_inputs:cuda())
             test_predictions[{{z,z+test_inputs:size(1) - 1},{}}] = output
         end
         for n = 1,numClasses do
             savePascal('test',test_predictions[{{},n}], n ,params.save)
		 end


	end
end

--filename = paths.concat(params.save,'meanIOUs.dat')
--	torch.save(filename,epochIOU)
--end



--torch.save(filename,keptModel)
	--	classTest = keptModel:forward(testData.data:cuda())
   --classValidation = torch.exp(keptModel:forward(valData.data)):select(2,2)
   --  --classTest = torch.exp(keptModel:forward(testData.data)):select(2,2)
   --   
   --      --local val_submission_name = string.format('%s%s%s','comp2_cls_val_',classNames[classID],'.txt')
   --        --local valfile = paths.concat(params.save,val_submission_name)
   --           --os.execute('mkdir -p ' .. sys.dirname(valfile))
   --            
