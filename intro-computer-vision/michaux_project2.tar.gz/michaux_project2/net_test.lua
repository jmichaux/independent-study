--[[ 
Imagenet classification tutorial by Sergey Zagoruyko.
Edited by Mohammadreza Mostajabi
]]--

require 'image'   
require 'nn'      
require 'cunn'
require 'loadcaffe'

function preprocess(im, mean_pix)
  -- rescale the image
  fixed_size = 227
  im3 = image.scale(im,fixed_size,fixed_size,'bilinear')*255
  -- RGB2BGR
  im4 = im3:index(1,torch.LongTensor{3,2,1}):float()
  -- subtract imagenet mean
  temp =image.scale(mean_pix, fixed_size, fixed_size, 'bilinear'):float() 
  return im4 - temp
end



function load_synset()
  local file = io.open '/share/project/vision-winter16/AlexNet/synset_words.txt'
  local list = {}
  while true do
    local line = file:read()
    if not line then break end
    table.insert(list, string.sub(line,11))
  end
  return list
end

---------------


model_file='/share/project/vision-winter16/AlexNet/bvlc_alexnet.caffemodel';
config_file='/share/project/vision-winter16/AlexNet/bvlc_alexnet.prototxt';
net = loadcaffe.load(config_file, model_file,'cudnn')
net:evaluate(); -- disabling dropouts by enabling evaluation mode 

filePath = '/share/project/vision-winter16/AlexNet/ilsvrc_2012_mean.t7' -- Imagenet mean image file
mean_pix = torch.load(filePath).img_mean:transpose(3,1)
synset_words = load_synset()
image_name = '/share/project/vision-winter16/AlexNet/car.jpg'
im = image.load(image_name)
prepim = preprocess(im,mean_pix):cuda()
netout = net:forward(prepim):float()

_,predictions = netout:sort(true)
for i=1,5 do
  print('predicted class '.. i ..': ', synset_words[predictions[i] ])
end
