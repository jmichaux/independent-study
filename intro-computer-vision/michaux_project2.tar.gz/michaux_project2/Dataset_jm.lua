require 'mattorch'
matio = require 'matio'
torch.setdefaulttensortype('torch.FloatTensor')

local filePath = '/share/project/vision-winter16/voc12-' .. subset ..'.mat'

local loaded = matio.load(filePath)  -- Loading lables and image names
imlist = loaded.Imlist

local t = {}
local s = {}
for i = 1, imlist:size()[1] do
	for j = 1, imlist:size()[2]  do
		t[j] = string.char(imlist[{i,j}])
  end
  s[i]=table.concat(t);
end

imlist = s --this list contains the names of the images
numimages = #imlist


datasetfeats = torch.Tensor(numimages,4096) -- Represent each image with 4096-dimensional feature vector
datasetfeats = torch.load('/share/project/vision-winter16/datasetfeats-voc12-' .. subset .. '.t7')


if subset == 'train' then
	trainsize = datasetfeats:size()[1]
	trainData = {
	   imlist = imlist,
	   data = datasetfeats:float(),
	   labels = loaded.labels:float(),
	   size = function() return trainsize end
	}
elseif subset == 'val' then
	valsize = datasetfeats:size()[1]
	valData = {
	   imlist = imlist,
	   data = datasetfeats:float(),
	   labels = loaded.labels:float(),
	   size = function() return valsize end
	}
elseif subset == 'test' then
	testsize = datasetfeats:size()[1]
	testData = {
	   imlist = imlist,
	   data = datasetfeats:float(),
	   size = function() return testsize end
	}
else 
	error("invalid subset")
end

