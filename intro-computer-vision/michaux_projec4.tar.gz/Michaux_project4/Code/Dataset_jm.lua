trainDataPath = '/home-nfs/jmichaux/project_4/data/trainData.mat'
trainGTPath = '/home-nfs/jmichaux/project_4/data/trainGT.mat'
valDataPath = '/home-nfs/jmichaux/project_4/data/valData.mat'
valGTPath = '/home-nfs/jmichaux/project_4/data/valGT.mat'

function load_image_names(filePath)
	local loaded = matio.load(filePath)
	im_list = loaded.Imlist or loaded.Imlistgt
	local t = {}
	local s = {}
	for i = 1, im_list:size()[1] do
		for j = 1, im_list:size()[2]  do
			t[j] = string.char(im_list[{i,j}])
  		end
  		s[i]=table.concat(t);
	end
	im_list = s --this list contains the names of the images
	return im_list	
end


--load training Data
trainData = {
	inputs = load_image_names(trainDataPath),
	targets = load_image_names(trainGTPath)
}
	
trainData['size'] = #trainData.inputs


--load validation data
valData = {
	inputs = load_image_names(valDataPath),
	targets = load_image_names(valGTPath)
}	
	valData['size'] = #valData.inputs


