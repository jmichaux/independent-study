#!/bin/bash
#SBATCH --job-name=jm_sbatch
#SBATCH --partition=contrib-gpu
#SBATCH --array=1-20

cd /home-nfs/jmichaux/Code;
#th run2.lua -dataType cuda -maxEpochs 70 -batchSize 30 -classWeight 1 -backgroundWeight 1 -classID ${SLURM_ARRAY_TASK_ID} -save problem_1;
#th run2.lua -initialize -1 -dataType cuda -maxEpochs 70 -batchSize 30 -classWeight -1 -backgroundWeight 1 -classID ${SLURM_ARRAY_TASK_ID} -save problem_5_2;
#th run2.lua -initialize -1 -dataType cuda -maxEpochs 70 -batchSize 30 -classWeight -1 -backgroundWeight 2 -classID ${SLURM_ARRAY_TASK_ID} -save problem_5_3a;
#th run2.lua -initialize -1 -dataType cuda -maxEpochs 70 -batchSize 30 -classWeight -1 -backgroundWeight 4 -classID ${SLURM_ARRAY_TASK_ID} -save problem_5_3b;
#th run2.lua -initialize -1 -dataType cuda -maxEpochs 70 -batchSize 30 -classWeight -1 -backgroundWeight 6 -classID ${SLURM_ARRAY_TASK_ID} -save problem_5_3c;
#th run2.lua -initialize -1 -dataType cuda -maxEpochs 70 -batchSize 30 -classWeight -1 -backgroundWeight 8 -classID ${SLURM_ARRAY_TASK_ID} -save problem_5_3d;
th run2.lua -initialize -1  -dataType cuda -maxEpochs 70 -batchSize 30 -classWeight -1 -backgroundWeight 4 -classID ${SLURM_ARRAY_TASK_ID} -save problem_5_4;

