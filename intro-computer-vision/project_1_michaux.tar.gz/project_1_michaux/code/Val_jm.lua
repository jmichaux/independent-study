-- This code computes the mean IOU accuracy on the validation set for each class
-- Your code goes here 

local val_true = torch.eq(true_labels, 2)
local val_neg = torch.eq(true_labels, 1)
local out_true = torch.eq(output_labels,2)
local out_neg = torch.eq(output_labels,1)

local TP = torch.eq(out_true + val_true,2):sum()
local FP = torch.eq(out_true + val_neg,2):sum()
local FN = torch.eq(out_neg + val_true,2):sum()

IOU = TP / (TP + FP + FN)
