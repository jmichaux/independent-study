--This code reads in a Tensory of IOUs for each class and  
--calculates the meanIOU for problems 1,2, and 3
--and saves their values in .dat files

lfs = require 'lfs'
require 'torch'
require 'nn'
require 'cutorch'
require 'cunn'
numClasses = 20
maxEpochs = 70
--problems = {'problem_5_2','problem_5_3a', 'problem_5_3b', 'problem_5_3c', 'problem_5_3d'}
problems = {'problem_4'}
baseDirectory = '/home-nfs/jmichaux/Code'
for i = 1, table.getn(problems) do
	problemDirectory = string.format('%s%s%s',baseDirectory,'/',problems[i]) --create name of directory where IOU
	lfs.chdir(problemDirectory)  --change directory to problem directory containing IOU files
	matIOU = torch.Tensor(numClasses, maxEpochs)
	for j = 1,numClasses do
		local datafilename = string.format('%s%d%s','class_',j,'_IOUs.dat')
		local a = torch.load(datafilename)
		matIOU[j] = a
	end
	meanIOU = matIOU:max(2):mean() --this mean is taken as the average of the max IOU for each class during 200 epochs
	local filename = string.format('%s%s',problems[i],'_meanIOU.dat')
	--lfs.chdir(baseDirectory)
	torch.save(filename,meanIOU)
end
