require 'nn'
require 'cunn'
require 'cutorch'

--some parameters of the model
pDropout = 0.5
numHidden = 1000
numOutput = 2
numInput = 4096


model = nn.Sequential()

model:add(nn.ReLU())
model:add(nn.Dropout(pDropout))
model:add(nn.Linear(numInput, numHidden))
model:add(nn.ReLU())
model:add(nn.Dropout(pDropout))
model:add(nn.Linear(numHidden, numOutput))
model:add(nn.LogSoftMax())


--negative log-loss

if params.initialize == -1 then
	model.modules[3].weight:copy(fc8.fc8weight)
	model.modules[3].bias:copy(fc8.fc8bias)
end



if classWeight == -1 then
	 classWeight = true_labels:size()[1] / torch.eq(true_labels,2):sum()
end

if backgroundWeight == -1 then
	backgroundWeight = true_labels:size()[1] / torch.eq(true_labels,1):sum() 
end

nllWeights = torch.Tensor({backgroundWeight, classWeight})
criterion = nn.ClassNLLCriterion(nllWeights)

if params.dataType == 'cuda' then
	model:cuda()
	criterion:cuda()
end
