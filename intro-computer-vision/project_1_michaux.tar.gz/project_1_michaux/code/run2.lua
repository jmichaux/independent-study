require 'torch'
require 'cutorch'
torch.setdefaulttensortype('torch.FloatTensor')

classNames = {}
classNames[1] = 'aeroplane'
classNames[2] = 'bicycle'
classNames[3] = 'bird'
classNames[4] = 'boat'
classNames[5] = 'bottle'
classNames[6] = 'bus'
classNames[7] = 'car'
classNames[8] = 'cat'
classNames[9] = 'chair'
classNames[10] = 'cow'
classNames[11] = 'diningtable'
classNames[12] = 'dog'
classNames[13] = 'horse'
classNames[14] = 'motorbike'
classNames[15] = 'person'
classNames[16] = 'pottedplant'
classNames[17] = 'sheep'
classNames[18] = 'sofa'
classNames[19] = 'train'
classNames[20] = 'tvmonitor'


cmd = torch.CmdLine()
cmd:option('-numClasses', 2,'enter number of classes' )
cmd:option('-classID', 5, 'enter max number of epochs')
cmd:option('-maxEpochs', 10, 'enter max number of epochs')
cmd:option('-classWeight', 1, 'enter class weight')
cmd:option('-backgroundWeight', 1, 'enter background wieght')
cmd:option('-learningRate', 1e-4, 'enter learning rate')
cmd:option('-batchSize', 30, 'enter batch size')
cmd:option('-initialize',1,'initialize hidden unit')
cmd:option('-weightDecay', 1e-2,'enter weight decay')
cmd:option('-momentum',0.9,'enter momentum')
cmd:option('-dataType', 'cuda', 'enter something')
cmd:option('-saveflag', true, 'enter saveflag')
cmd:option('-save', 'results2', 'enter something') --name of the directory


params = cmd:parse(arg)
numClasses = params.numClasses
classID = params.classID
maxEpochs = params.maxEpochs
backgroundWeight = params.backgroundWeight
classWeight = params.classWeight
dataType = params.dataType


classIOU = torch.Tensor(maxEpochs) --vector of of IOUs for a specific class (#classID)

 -- load training data
subset = 'train'
dofile('Dataset_jm.lua')

 --load validation data
subset = 'val'
dofile('Dataset_jm.lua')
local valIdentifier = s

--load test data
subset = 'test'
dofile('Dataset_jm.lua')
local testIdentifier = s

--change to cuda
if params.dataType == 'cuda' then
	valData.data = valData.data:cuda()
        valData.labels = valData.labels:cuda()
	testData.data = testData.data:cuda()
end
true_labels = valData.labels:add(1)


--load new weights
fc8 = torch.load('/share/project/vision-winter16/fc8.t7')
dofile('Training_jm.lua')
local maxIOU = 0
local bestEpoch = 0
local keptModel = 0
for j = 1,maxEpochs do
	if maxEpochs%10 == 0 then
		opt.learningRate = opt.learningRate/10
	end
	train()
	model:evaluate()
	_,output_labels = model:forward(valData.data):max(2) --model forward is the prediction
	dofile('Val_jm.lua')
	if maxIOU < IOU then
		maxIOU = IOU
		keptModel = model
		bestEpoch = j
	end	
	classIOU[j] = IOU
end

classValidation = torch.exp(keptModel:forward(valData.data)):select(2,2)

classTest = torch.exp(keptModel:forward(testData.data)):select(2,2)

local val_submission_name = string.format('%s%s%s','comp2_cls_val_',classNames[classID],'.txt')
local valfile = paths.concat(params.save,val_submission_name)
os.execute('mkdir -p ' .. sys.dirname(valfile))

local iouName = string.format('class_%d_IOUs.dat',classID)
local ioufile = paths.concat(params.save, iouName)
torch.save(ioufile,classIOU)

getmetatable('').__call = string.sub

--write the validation submission file
fp = io.open(valfile, 'w+')
for k = 1,classValidation:size()[1] do
        fp:write(string.format('%s%s%s\n', valIdentifier[k](61,-5), ' ', classValidation[k]))
end
io.close(fp)


local test_submission_name = string.format('%s%s%s','comp2_cls_test_',classNames[classID],'.txt')
local testfile = paths.concat(params.save,test_submission_name)
 --this is the entire path for the file to be saved
os.execute('mkdir -p ' .. sys.dirname(testfile))  --make the directory where the file will go


--write the test submission file
fp = io.open(testfile, 'w+')
for k = 1,classTest:size()[1] do
        fp:write(string.format('%s%s%s\n', testIdentifier[k](61,-5), ' ', classTest[k]))
end
io.close(fp)



--torch.save(filename,keptModel) -- saving the IOUs  after each epoch










